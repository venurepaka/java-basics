public class SimpleCalculator {
    static int undefined = 1 / 0;
}