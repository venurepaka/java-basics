package com.junit.ex;


import static org.junit.Assert.*;

import org.junit.Test;


public class TestUsingJUnit1{


	   @Test
	   public void testPrintMessage() {	
	      assertEquals("abc1", "abc1");     
	   }
	   
	
	
	
}
