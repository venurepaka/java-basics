package com.junit.ex;



import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({TestUsingJUnit.class, TestUsingJUnit1.class})
public class TestUsingJUnitSuite{
	
}

 

