package com.rest.examples;

import java.util.Arrays;

public class SortArray {

	public int[] sortArrayNumbers(int[] numbers) {
		
		
		
		return numbers;
		
	}
	
	public static void main(String[] args) {
//		int[] nums = new int[] {3,6,9,2,56,76,11,10};
		
		String[] nums = new String[] {"one","two","three","four","five"};
		SortArray sortArr = new SortArray();
		Arrays.sort(nums);
		System.out.println(Arrays.toString(nums));
		//sortArr.sortArrayNumbers(nums);
		
		
		
	}
	
	
	
	
}
