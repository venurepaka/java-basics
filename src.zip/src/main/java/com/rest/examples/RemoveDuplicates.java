package com.rest.examples;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.ArrayUtils;

public class RemoveDuplicates {
	
	
//	public Set<Integer> removeDuplicateNumbers(int[] numbers) {
//		Set<Integer> s = new HashSet<Integer>();
//		for(int i=0; i<numbers.length; i++) {
//			if( s.add(numbers[i]) ==  false) {
//				System.out.println("duplicate number = "+ numbers[i]);
//			}
//			
//		}
//		return s;
//	}
	
	public int[] removeDuplicateNumbers(int[] numbers) {
	Set<Integer> s = new HashSet<Integer>();
	int[] numbers1 = null;
	for(int i=0; i<numbers.length; i++) {
		
		if( s.add(numbers[i]) ==  false) {
			
			System.out.println("duplicate number = "+ numbers[i]);
			
			numbers1 = ArrayUtils.remove(numbers, i);
			numbers = numbers1;
			i = i-1;
			System.out.println("");
			
		}
		
	}
	
	return numbers;
	
}
	
	
	public static void main(String[] args) {
		int[] nums = new int[] {5,6,7,8,9,5,6,4,3,10};
		RemoveDuplicates removeDuplicates = new RemoveDuplicates();
//		Set<Integer> s = removeDuplicates.removeDuplicateNumbers(nums);
//		System.out.println(s); 
		
		int[] numbers = removeDuplicates.removeDuplicateNumbers(nums);
		System.out.println(numbers[5]);
	}
}
