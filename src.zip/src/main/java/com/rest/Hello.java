package com.rest;

import org.testng.annotations.Test;


public class Hello {

	public static void main(String[] args) {
		System.out.println("done");
	}
	
	@Test
	public void t1() {
		System.out.println("in t1");
		
	}
	
	@Test
	public void test2() {
		System.out.println("in t2");
		
		
	}
	
	
}
