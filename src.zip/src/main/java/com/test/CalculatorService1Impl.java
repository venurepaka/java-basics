package com.test;

public class CalculatorService1Impl extends CalculatorService1{

	
	public int multiply(int i, int j) {
		
		return i*j;
	}

}
