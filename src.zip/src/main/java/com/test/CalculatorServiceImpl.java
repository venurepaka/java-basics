package com.test;

public class CalculatorServiceImpl implements CalculatorService{

	
	public int add(int i, int j) {
		return i+j;
	}
	

}
