package com.test;

public interface CalculatorService {
	
	public abstract int add(int i, int j);
	
	
}
