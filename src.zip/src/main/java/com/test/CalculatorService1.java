package com.test;

public abstract class CalculatorService1 {
	public abstract int multiply(int i, int j);
}
