package com.test;

public class Parent {
   protected int x = 9; // protected access
}